﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace $rootnamespace$
{
	public class $safeitemrootname$
	{
		// TODO: add properties to the model
	}
}