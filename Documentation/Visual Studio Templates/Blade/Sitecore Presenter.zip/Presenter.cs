﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blade;

namespace $rootnamespace$
{
	public class $safeitemrootname$ : SitecorePresenter<object>
	{
		// TODO: fill in the model type in the SitecorePresenter inheritance statement, then implement the abstract class
	}
}