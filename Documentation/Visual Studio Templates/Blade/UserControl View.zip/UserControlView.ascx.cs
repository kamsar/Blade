﻿using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Synthesis;
using Blade.Views;

namespace $rootnamespace$
{
	public partial class $classname$ : UserControlView<IStandardTemplateItem>
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}