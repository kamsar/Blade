﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Synthesis;
using Blade.Views;
using System.Web.UI;

namespace $rootnamespace$ {
	public class $safeitemrootname$ : WebControlView<IStandardTemplateItem>
	{
		protected override void RenderModel(HtmlTextWriter writer)
		{
			throw new NotImplementedException();
		}
	}
}